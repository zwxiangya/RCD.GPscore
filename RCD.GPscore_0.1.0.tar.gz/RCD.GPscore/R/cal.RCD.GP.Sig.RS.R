#'@title Calculation of the risk score of the overall survivlal, based on the constructed RCD gene pairs
#' @param exprset A cohort matrix with the genes as the colnames, sample names as the rownamses.
#' @author Wei Zhang
#'
#' @return A dataframe that contains the risk score
#'
#' @export
#' @examples
#' \dontrun{
#' data("GBM.exp.tcga")
#' dd = cal.RCD.GP.Sig.RS(exprset = GBM.exp.tcga)
#' }


cal.RCD.GP.Sig.RS = function(exprset){


if(T){
  data("ID.gene.pair")
  data("final.candicate.gene")
}


  colnames(exprset) = gsub("-",".",colnames(exprset))


  ## generating the gene pari matrix
  IRGP.generator <- function(expr = NULL, immuneGene = NULL) {

    imm_mat <- as.data.frame(t(combn(immuneGene, 2, simplify = T))) # Constructing permutations of genes
    rownames(imm_mat) <- paste0("P",rownames(imm_mat))
    colnames(imm_mat) <- c("IRGP1","IRGP2") # The permutations are categorized as IRGP1 and IRGP2.
    IRGP_matrix_1 <- expr[as.character(imm_mat$IRGP1),] #
    IRGP_matrix_2 <- expr[as.character(imm_mat$IRGP2),]

    IRGP_matrix <- IRGP_matrix_1 - IRGP_matrix_2
    for( p in 1:ncol(IRGP_matrix)){
      IRGP_matrix[,p] <- ifelse(IRGP_matrix[,p] < 0,1,0) #
    }
    rownames(IRGP_matrix) <- rownames(imm_mat)

    return(list(IRGP_matrix = IRGP_matrix, IRGP_info = imm_mat))
  }






  if(length(unique( final.candicate.gene%in%colnames(exprset)))==1){


    tmp.IRPG = IRGP.generator(expr = as.data.frame(t(exprset)), #
                              immuneGene = final.candicate.gene)

  } else {

    gene.not.in = final.candicate.gene[which(!final.candicate.gene%in%colnames(exprset))]
    not.matrix = matrix(data= rep(0,length(gene.not.in)*nrow(exprset)), nrow =nrow(exprset),ncol =length(gene.not.in)  )
    not.matrix =as.data.frame(not.matrix)
    colnames(not.matrix) = gene.not.in
    exprset = cbind(exprset,not.matrix)
    tmp.IRPG = IRGP.generator(expr = as.data.frame(t(exprset)), #
                              immuneGene = final.candicate.gene)

  }

  tmp.IRPG.matrix =  tmp.IRPG$IRGP_matrix
  tmp.IRPG.info =  tmp.IRPG$IRGP_info
  tmp.IRPG.matrix.RS = tmp.IRPG.matrix[ID.gene.pair,]
  riskscore = data.frame(ID= colnames(tmp.IRPG.matrix.RS),
                         Riskscore = apply(tmp.IRPG.matrix.RS, 2, sum))
  return(riskscore)

}









